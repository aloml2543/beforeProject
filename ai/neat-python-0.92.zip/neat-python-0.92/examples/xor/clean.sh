#!/usr/bin/env bash
rm *.csv *.gv *.svg
rm neat-checkpoint-*