#!/usr/bin/env bash
rm genome-*.bin image-*.png
rm winning-novelty-*.png novelty-*.png