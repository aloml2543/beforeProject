#!/usr/bin/env bash
rm *.csv *.gv *.svg
rm winner*
rm neat-checkpoint-*